/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ejemplo.logica;

/**
 *
 * @author usuario
 */
public class AreaFiguras {
    double area;
    /*Métodos que permiten calcular las areas, estos reciben
      como parámetros el lado, base, altura y radio, dependiendo cada caso.
    */
    public double areaCuadrado(double lado) {
        area = lado * lado;
        return area;
    }
    
    public double areaRectangulo(double base, double altura) {
        area = base * altura;
        return area;
    }
    
    public double areaTriangulo(double base, double altura) {
        area = (base * altura)/2;
        return area;
    }
    
    public double areaCirculo(double radio) {
        area = Math.PI*radio*radio;
        return area;
    }
}
