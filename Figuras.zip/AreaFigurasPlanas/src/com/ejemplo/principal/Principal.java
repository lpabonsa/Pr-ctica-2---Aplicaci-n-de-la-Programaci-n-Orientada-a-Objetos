/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ejemplo.principal;

import com.ejemplo.logica.AreaFiguras;
import java.util.Scanner;

/**
 *
 * @author usuario
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        AreaFiguras af = new AreaFiguras();
        Scanner sc = new Scanner(System.in);
        
        double lado, altura, base, radio; //Variables de tipo double
        System.out.print("Ingrese el lado del cuadrado: "); //Pedimos el lado por teclado
        lado = sc.nextDouble(); //Almacenamos el lado en la variable lado
        System.out.print("Ingrese la base del triangulo: "); 
        base = sc.nextDouble(); 
        System.out.print("Ingrese la altura del triangulo: "); 
        altura = sc.nextDouble(); 
        System.out.print("Ingrese la base del rectangulo: ");
        base = sc.nextDouble(); 
        System.out.print("Ingrese la altura del rectangulo: "); 
        altura = sc.nextDouble(); 
        System.out.print("Ingrese el radio del circulo: "); 
        radio = sc.nextDouble(); 
        /*
         * En las siguientes lineas invocamos los diferentes métodos que
         * trae nuestro objeto "af" y mostramos el resultado por consola.
         */
        System.out.println("------------------------------------------");
        System.out.println("El area del cuadrado es: " + af.areaCuadrado(lado));
        System.out.println("El area del triangulo es: " + af.areaTriangulo(base, altura));
        System.out.println("El area del rectangulo es: " + af.areaRectangulo(base, altura));
        System.out.println("El area del circulo es: " + af.areaCirculo(radio));

    }
    
}
